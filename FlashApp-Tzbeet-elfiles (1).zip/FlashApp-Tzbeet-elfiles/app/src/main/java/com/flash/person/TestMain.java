package com.flash.person;


public class TestMain {
    public static void main(String[] args){
        User user = new User();

    }
}
